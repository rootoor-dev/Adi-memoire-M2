package la4j.util;

public final class Pair<T1, T2> {
	public final T1 ob1;
	public final T2 ob2;

	public Pair(T1 _ob1, T2 _ob2) {
		ob1 = _ob1;
		ob2 = _ob2;
	}
}
