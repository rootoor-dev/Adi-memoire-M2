package la4j.err;

public class PropNumbersProblemException extends Exception {

	public PropNumbersProblemException() {
		super();
	}

	public PropNumbersProblemException(String msg) {
		super(msg);
	}
}
