package la4j.err;

public class VectorException extends Exception {

	public VectorException() {
		super();
	}

	public VectorException(String msg) {
		super(msg);
	}
}
