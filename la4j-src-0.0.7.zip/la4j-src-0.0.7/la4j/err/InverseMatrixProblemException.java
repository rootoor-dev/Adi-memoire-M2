package la4j.err;

public class InverseMatrixProblemException extends Exception {

	public InverseMatrixProblemException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InverseMatrixProblemException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
}
