package la4j.err;

public class MatrixException extends Exception {

	public MatrixException() {
		super();
	}

	public MatrixException(String msg) {
		super(msg);
	}

}
