package la4j.err;

public class LinearEquationException extends Exception {

	public LinearEquationException() {
		super();
	}

	public LinearEquationException(String msg) {
		super(msg);
	}

}
