package la4j.vector;

import java.util.Random;

public abstract class VectorFactory {
	private VectorFactory() {
	}

	public static Vector createVector() {
		return new Vector();
	}

	public static Vector createVector(int len) {
		return new Vector(len);
	}

	public static Vector createVector(double array[]) {
		return new Vector(array);
	}

	public static Vector createVectorWithCopy(double array[]) {
		double arraycopy[] = new double[array.length];

		System.arraycopy(array, 0, arraycopy, 0, array.length);

		return new Vector(arraycopy);
	}

	public static Vector createRandomVector(int len) {

		Vector v = new Vector(len);

		Random r = new Random();
		for (int i = 0; i < len; i++) {
			v.set(i, r.nextDouble());
		}

		return v;
	}
	
}
