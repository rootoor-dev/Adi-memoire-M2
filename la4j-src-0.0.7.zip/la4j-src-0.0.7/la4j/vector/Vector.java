package la4j.vector;

import java.util.Arrays;

import la4j.err.VectorException;

public class Vector implements Cloneable {
	private double vector[];
	private int length;

	public Vector() {
		length = 0;
		vector = new double[0];
	}

	public Vector(double array[]) {
		length = array.length;
		vector = array;
	}

	public Vector(int len) {
		length = len;
		vector = new double[length];
	}

	public double get(int i) {
		return vector[i];
	}

	public void set(int i, double value) {
		vector[i] = value;
	}

	public int length() {
		return length;
	}

	@Override
	public Vector clone() {
		Vector clon = new Vector(length);

		System.arraycopy(vector, 0, clon.vector, 0, length);

		return clon;
	}

	public double[] toArray() {
		return vector;
	}

	public double[] toArrayCopy() {
		double arraycopy[] = new double[length];

		System.arraycopy(vector, 0, arraycopy, 0, length);

		return arraycopy;
	}

	public void setLength(int length) {
		this.length = length;

		vector = Arrays.copyOf(vector, length);
	}

	public Vector add(double d) {
		double self[] = new double[length];
		for (int i = 0; i < length; i++) {
			self[i] = vector[i] + d;
		}

		return new Vector(self);
	}

	public Vector add(Vector v) throws VectorException {
		if (length == v.length) {
			double self[] = new double[length];
			for (int i = 0; i < length; i++) {
				self[i] = vector[i] + v.vector[i];
			}

			return new Vector(self);
		} else {
			throw new VectorException(
					"can not sum this vectors: wrong dimmentions");
		}
	}

	public Vector multiply(double d) {
		double self[] = new double[length];
		for (int i = 0; i < length; i++) {
			self[i] = vector[i] * d;
		}

		return new Vector(self);
	}

	public Vector multiply(Vector v) throws VectorException {
		if (length == v.length) {
			double self[] = new double[length];
			for (int i = 0; i < length; i++) {
				self[i] = vector[i] * v.vector[i];
			}

			return new Vector(self);
		} else {
			throw new VectorException(
					"can not sum this vectors: wrong dimmentions");
		}

	}

	public Vector substract(double d) {
		double self[] = new double[length];
		for (int i = 0; i < length; i++) {
			self[i] = vector[i] - d;
		}

		return new Vector(self);
	}

	public Vector substsract(Vector v) throws VectorException {
		if (length == v.length) {
			double self[] = new double[length];
			for (int i = 0; i < length; i++) {
				self[i] = vector[i] - v.vector[i];
			}

			return new Vector(self);
		} else {
			throw new VectorException(
					"can not sum this vectors: wrong dimmentions");
		}
	}

	public Vector div(double d) {
		double self[] = new double[length];
		for (int i = 0; i < length; i++) {
			self[i] = vector[i] / d;
		}
		return new Vector(self);
	}

	public Vector div(Vector v) throws VectorException {
		if (length == v.length) {
			double self[] = new double[length];
			for (int i = 0; i < length; i++) {
				self[i] = vector[i] / v.get(i);
			}
			return new Vector(self);
		} else {
			throw new VectorException(
					"can not sum this vectors: wrong dimmentions");
		}
	}

	public double scalarProduct(Vector v) throws VectorException {
		if (length == v.length) {
			double s = 0.0;
			for (int i = 0; i < vector.length; i++) {
				s += vector[i] * v.vector[i];
			}

			return s;
		} else {
			throw new VectorException(
					"can not calc scalar product of this vectors: wrong dimmentions");
		}
	}

	public double norm() {
		try {
			return Math.sqrt(scalarProduct(this));
		} catch (VectorException ex) {
			return 0.0;
		}
	}

	public Vector normalize() {
		return div(norm());
	}

	public void swap(int i, int j) {
		double d = vector[i];
		vector[i] = vector[j];
		vector[j] = d;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for (int i = 0; i < vector.length; i++) {
			sb.append(String.format("%6.3f", vector[i]));
			sb.append((i < vector.length - 1 ? ", " : ""));
		}
		sb.append("]");

		return sb.toString();

	}

}
