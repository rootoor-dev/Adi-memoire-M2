package la4j.vector;

import la4j.err.VectorException;

public abstract class VectorUtils {
	private VectorUtils() {
	}

	public static Vector multiply(Vector a, double d) {
		return a.multiply(d);
	}

	public static Vector multiply(Vector a, Vector b) throws VectorException {
		return a.multiply(b);
	}

	public static Vector add(Vector a, double d) {
		return a.add(d);
	}

	public static Vector add(Vector a, Vector b) throws VectorException {
		return a.add(b);
	}

	public static Vector substract(Vector a, double d) {
		return a.substract(d);
	}

	public static Vector substract(Vector a, Vector b) throws VectorException {
		return a.substsract(b);
	}

	public static double scalarProduct(Vector a, Vector b)
			throws VectorException {
		return a.scalarProduct(b);
	}

	public static Vector div(Vector a, double d) {
		return a.div(d);
	}
	
	public static Vector div(Vector a, Vector b) throws VectorException {
		return a.div(b);
	}

	public static Vector normalize(Vector a) {
		return a.normalize();
	}

	public static double norm(Vector a) {
		return a.norm();
	}

	public static Vector expandVector(Vector a, double d) {
		Vector b = a.clone();
		b.setLength(b.length() + 1);
		b.set(b.length() - 1, d);

		return b;
	}

}
