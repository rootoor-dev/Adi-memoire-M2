package la4j;

public class Demo {

	public static void main(String args[]) throws Exception {
		
	}
	
}
