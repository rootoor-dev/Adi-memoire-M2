package la4j.linear;

import la4j.matrix.Matrix;
import la4j.vector.Vector;
import la4j.linear.AbstractLinearEquation;
import la4j.err.LinearEquationException;
import la4j.linear.LinearEquation;

public class LEImplJacobiDecompositor extends AbstractLinearEquation implements
		LinearEquation {
	
	private final static int MAX_ITERATIONS = 100000;

	public LEImplJacobiDecompositor(Matrix _a, Vector _b) {
		super(_a, _b);
	}

	@Override
	public Vector getSolution() throws LinearEquationException {

		if (!isMethodCanBeUsed()) {
			throw new LinearEquationException("method Jacobi can not be used");
		} else {

			Vector current = new Vector(variables());

			double aa[][] = a.toArrayCopy(); // get coefficients
			int iteration = 0;

			for (int i = 0; i < a.rows(); i++) {
				for (int j = 0; j < a.columns(); j++) {
					if (i != j) {
						aa[i][j] /= aa[i][i];
					}
				}
			}

			while (iteration < MAX_ITERATIONS && !isSolution(current)) {

				Vector next = new Vector(current.length());

				for (int i = 0; i < a.rows(); i++) {
					double sum = b.get(i) / aa[i][i];
					for (int j = 0; j < a.columns(); j++) {
						if (i != j) {
							sum -= aa[i][j] * current.get(j);
						}
					}

					next.set(i, sum);
				}

				current = next;

				iteration++;

			}

			if (iteration == MAX_ITERATIONS) {
				throw new LinearEquationException(
						"method Jacobi can not be used");
			}

			return current;
		}

	}

	private boolean isMethodCanBeUsed() {
		for (int i = 0; i < a.rows(); i++) {
			double sum = 0;

			for (int j = 0; j < a.columns(); j++) {
				if (i != j) {
					sum += Math.abs(a.get(i, j));
				}
			}

			if (sum > Math.abs(a.get(i, i)) - EPS) {
				return false;
			}
		}

		return true;
	}
}
