package la4j.linear;

import la4j.err.LinearEquationException;
import la4j.matrix.Matrix;
import la4j.matrix.MatrixFactory;
import la4j.vector.Vector;
import la4j.vector.VectorFactory;

public class LEImplSqrtDecompositor extends AbstractLinearEquation implements
		LinearEquation {

	public LEImplSqrtDecompositor(Matrix _a, Vector _b) {
		super(_a, _b);
	}

	@Override
	public Vector getSolution() throws LinearEquationException {
		/* try to build A = St D S */

		Matrix s = MatrixFactory.createSquareMatrix(equations());
		Matrix d = MatrixFactory.createSquareMatrix(equations());

		Vector x = VectorFactory.createVector(variables());
		Vector y = VectorFactory.createVector(variables());
		Vector z = VectorFactory.createVector(variables());

		double sum = 0;

		/* check matrix to symmetric */
		if (!a.isSymmetric()) {
			throw new LinearEquationException("matrix a is not symmetric");
		}

		for (int i = 0; i < a.rows(); i++) {

			/* get dii */
			sum = 0;
			for (int l = 0; l < i; l++) {
				sum += Math.pow(s.get(l, i), 2) * d.get(l, l);
			}

			d.set(i, i, Math.signum(a.get(i, i) - sum));

			/* get sii */
			sum = 0;
			for (int l = 0; l < i; l++) {
				sum += s.get(l, i) * s.get(l, i) * d.get(l, l);
			}

			s.set(i, i, Math.sqrt(Math.abs(a.get(i, i) - sum)));

			if (Math.abs(s.get(i, i)) < EPS) {
				throw new LinearEquationException(
						"matrix s contains '0' at main diagonal");
			}

			/* get sij */
			for (int j = i + 1; j < a.columns(); j++) {
				sum = 0;
				for (int l = 0; l < i; l++) {
					sum += s.get(l, i) * s.get(l, i) * d.get(l, l);
				}
				s.set(i, j, (a.get(i, j) - sum) / (s.get(i, i) * d.get(i, i)));

			}

			/* get zi */
			sum = 0;
			for (int l = 0; l < i; l++) {
				sum += z.get(l) * s.get(l, i);
			}
			z.set(i, (b.get(i) - sum) / s.get(i, i));

			/* get yi */
			y.set(i, z.get(i) / d.get(i, i));

		}

		/* try to calc xi */

		for (int i = a.rows() - 1; i >= 0; i--) {
			sum = 0;
			for (int l = i + 1; l < a.columns(); l++) {
				sum += x.get(l) * s.get(i, l);
			}

			x.set(i, (y.get(i) - sum) / s.get(i, i));
		}

		return x;

	}
}
