package la4j.linear;

import la4j.err.InverseMatrixProblemException;
import la4j.err.LinearEquationException;
import la4j.matrix.Matrix;
import la4j.matrix.MatrixFactory;
import la4j.matrix.MatrixUtils;
import la4j.vector.Vector;
import la4j.vector.VectorFactory;

public class IMPImplGausDecompositor extends AbstractInverseMatrixProblem
		implements InverseMatrixProblem {

	public IMPImplGausDecompositor(Matrix a) {
		super(a);
	}

	@Override
	public Matrix getInverseMatrix() throws InverseMatrixProblemException {

		Matrix treangle = MatrixUtils
				.createTreangleMatrixKeepCoeficients(matrix);
		double inverse[][] = new double[treangle.columns()][treangle.rows()];

		try {

			for (int i = 0; i < treangle.rows(); i++) {
				Vector ident = VectorFactory.createVector(treangle.rows());
				ident.set(i, 1.0);

				for (int j = 0; j < treangle.rows() - 1; j++) {
					for (int k = j + 1; k < treangle.columns(); k++) {
						double identk = ident.get(k) - ident.get(j)
								* treangle.get(k, j);
						ident.set(k, identk);
					}
				}

				Vector x = retraceGaus(treangle, ident);
				inverse[i] = x.toArray();
			}

		} catch (LinearEquationException ex) {
			throw new InverseMatrixProblemException(ex.getMessage());
		}

		return MatrixFactory.createMatrix(inverse).transpose();
	}

	private Vector retraceGaus(Matrix a, Vector b)
			throws LinearEquationException {

		if (a.trace() == (double) 0.0) {
			throw new LinearEquationException("linear equation has no solution");
		}

		double x[] = new double[a.columns()];
		for (int i = x.length - 1; i >= 0; i--) {
			double summand = 0;
			for (int j = i + 1; j < x.length; j++) {
				summand += x[j] * a.get(i, j);
			}

			x[i] = (b.get(i) - summand) / a.get(i, i);

		}

		return new Vector(x);
	}

}
