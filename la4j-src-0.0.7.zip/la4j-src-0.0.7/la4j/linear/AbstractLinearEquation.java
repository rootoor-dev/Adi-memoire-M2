package la4j.linear;

import la4j.err.MatrixException;
import la4j.err.VectorException;
import la4j.matrix.Matrix;
import la4j.vector.Vector;
import la4j.err.LinearEquationException;

public abstract class AbstractLinearEquation implements LinearEquation {
	public static final double EPS = 10e-7;

	protected Matrix a;
	protected Vector b;

	public AbstractLinearEquation(Matrix _a, Vector _b) {
		a = _a;
		b = _b;
	}

	@Override
	public int equations() {
		return b.length();
	}

	@Override
	public int variables() {
		return a.columns();
	}

	@Override
	public Matrix getCoefficients() {
		return a;
	}

	@Override
	public Vector getRightHandColumn() {
		return b;
	}

	@Override
	public boolean isSolution(Vector x) {
		try {
			Vector r = getInnacary(x);

			boolean ret = true;

			for (int i = 0; i < r.length(); i++) {
				ret = ret && (Math.abs(r.get(i)) < EPS);
			}

			return ret;

		} catch (LinearEquationException ex) {
			return false;
		}
	}

	@Override
	public Vector getInnacary(Vector x) throws LinearEquationException {
		try {

			return a.multiply(x).substsract(b);

		} catch (MatrixException ex) {
			throw new LinearEquationException(ex.getMessage());
		} catch (VectorException ex) {
			throw new LinearEquationException(ex.getMessage());
		}

	}

}
