package la4j.linear;

import la4j.matrix.Matrix;
import la4j.vector.Vector;
import la4j.err.LinearEquationException;

public interface LinearEquation {

	public int equations();

	public int variables();

	public Matrix getCoefficients();

	public Vector getRightHandColumn();

	public Vector getSolution() throws LinearEquationException;

	public boolean isSolution(Vector x);

	public Vector getInnacary(Vector x) throws LinearEquationException;

}
