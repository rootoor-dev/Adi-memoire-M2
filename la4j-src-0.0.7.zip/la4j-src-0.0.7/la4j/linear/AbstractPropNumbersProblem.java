package la4j.linear;

import la4j.matrix.Matrix;

public abstract class AbstractPropNumbersProblem implements PropNumbersProblem {

	protected static final double EPS = 10e-7;

	protected Matrix matrix;

	public AbstractPropNumbersProblem(Matrix _matrix) {
		matrix = _matrix;
	}

	@Override
	public Matrix getMatrix() {
		return matrix;
	}

}
