package la4j.linear;

import la4j.matrix.Matrix;
import la4j.vector.Vector;
import la4j.util.Pair;
import la4j.err.PropNumbersProblemException;

public interface PropNumbersProblem {

	public Matrix getMatrix();

	public Pair<Double, Vector>[] getPropNumbers()
			throws PropNumbersProblemException;

}
