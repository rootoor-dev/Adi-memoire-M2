package la4j.linear;

import la4j.err.LinearEquationException;
import la4j.matrix.Matrix;
import la4j.vector.Vector;
import la4j.vector.VectorFactory;

public class LEImplSweepDecompositor extends AbstractLinearEquation implements LinearEquation {

	public LEImplSweepDecompositor(Matrix a, Vector b) {
		super(a, b);
		
	}

	@Override
	public Vector getSolution() throws LinearEquationException {
		
		int n = variables(); 
		
		Vector x = VectorFactory.createVector(n);
		
		for (int i=0; i<n-1; i++) {
			double max = Math.abs(a.get(i, i));
			
			int maxi = i;
			for (int j=i + 1; j < n; j++) {
				if (Math.abs(a.get(j, i)) > max) {
					max = Math.abs(a.get(j , i));
					maxi = j;
				}
			}
			
			if (maxi != i) {
				for (int j=0; j<n; j++) {
					double t = a.get(i, j);
					a.set(i, j, a.get(maxi, j));
					a.set(maxi, j, t);
				}
				
				double tt = b.get(i);
				b.set(i, b.get(maxi));
				b.set(maxi, tt);
			}
			
			for (int j=i+1; j<n; j++) {
				double c = a.get(j, i) / a.get(i, i);
				for (int k=i; k<n; k++) {
					a.set(j, k, a.get(j, k) - a.get(i, k) * c);
				}

				b.set(j, b.get(j) - b.get(i) * c);
			}
		}
		
		for (int i=n-1; i>=0; i--) {
			double sum = 0;
			for (int j=i+1; j<n; j++) {
				sum += a.get(i, j) * x.get(j);
			}
			
			x.set(i, (b.get(i) - sum) / a.get(i, i));
		}
		
		
		return x;
	}

}
