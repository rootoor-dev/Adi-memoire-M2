package la4j.linear;

import java.util.ArrayList;
import java.util.List;

import la4j.matrix.Matrix;
import la4j.vector.Vector;
import la4j.vector.VectorFactory;
import la4j.util.Pair;
import la4j.err.PropNumbersProblemException;
import la4j.err.MatrixException;
import la4j.err.VectorException;

public class PNPImplPartlyDecompositor extends AbstractPropNumbersProblem
		implements PropNumbersProblem {

	public PNPImplPartlyDecompositor(Matrix _matrix) {
		super(_matrix);
	}

	private Pair<Double, Vector> getFirstPropNumber()
			throws PropNumbersProblemException {
		Pair<Double, Vector> first = null;

		Vector x = VectorFactory.createRandomVector(matrix.columns());
		x = x.multiply(10000);

		double currentLambda = 0.0, lastLambda = 0.0;

		try {

			do {

				lastLambda = currentLambda;

				Vector xn = matrix.multiply(x);
				currentLambda = xn.scalarProduct(x) / x.scalarProduct(x);
				double norm = xn.norm();

				/* normalize vector */
				for (int i = 0; i < xn.length(); i++) {
					xn.set(i, xn.get(i) / norm);
				}

				x = xn;

			} while (Math.abs(currentLambda - lastLambda) > EPS);

			first = new Pair<Double, Vector>(currentLambda, x);

		} catch (MatrixException ex) {
			throw new PropNumbersProblemException(ex.getMessage());
		} catch (VectorException ex) {
			throw new PropNumbersProblemException(ex.getMessage());
		}

		return first;
	}

	private Pair<Double, Vector> getSecondPropNumber()
			throws PropNumbersProblemException {
		Pair<Double, Vector> second = null;

		Vector x = VectorFactory.createRandomVector(matrix.columns());
		x = x.multiply(10000);

		double currentLambda = 0.0, lastLambda = 0.0;

		Vector e1 = getFirstPropNumber().ob2;

		/* save values */
		Matrix oldMatrix = matrix;
		matrix = matrix.transpose();

		Vector g1 = getFirstPropNumber().ob2;

		matrix = oldMatrix;

		try {

			double k = x.scalarProduct(g1) / e1.scalarProduct(g1);

			for (int i = 0; i < x.length(); i++) {
				x.set(i, x.get(i) - k * e1.get(i));
			}

			do {
				lastLambda = currentLambda;

				Vector xn = matrix.multiply(x);
				currentLambda = xn.scalarProduct(x) / x.scalarProduct(x);
				double norm = xn.norm();

				for (int i = 0; i < xn.length(); i++) {
					xn.set(i, xn.get(i) / norm);
				}

				k = xn.scalarProduct(g1) / g1.scalarProduct(e1);

				for (int i = 0; i < xn.length(); i++) {
					xn.set(i, xn.get(i) - k * e1.get(i));
				}

				x = xn;

			} while (Math.abs(currentLambda - lastLambda) > EPS);

			second = new Pair<Double, Vector>(currentLambda, x);

		} catch (VectorException ex) {
			throw new PropNumbersProblemException(ex.getMessage());
		} catch (MatrixException ex) {
			throw new PropNumbersProblemException(ex.getMessage());
		}

		return second;
	}

	@Override
	public Pair<Double, Vector>[] getPropNumbers()
			throws PropNumbersProblemException {

		List<Pair<Double, Vector>> nums = new ArrayList<Pair<Double, Vector>>();

		nums.add(getFirstPropNumber());
		nums.add(getSecondPropNumber());

		return nums.toArray((Pair<Double, Vector>[]) new Pair[nums.size()]);
	}

}
