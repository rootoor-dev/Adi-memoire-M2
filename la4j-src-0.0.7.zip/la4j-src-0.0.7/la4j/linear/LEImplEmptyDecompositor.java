package la4j.linear;

import la4j.err.LinearEquationException;
import la4j.matrix.Matrix;
import la4j.vector.Vector;

public class LEImplEmptyDecompositor extends AbstractLinearEquation implements
		LinearEquation {

	public LEImplEmptyDecompositor(Matrix _a, Vector _b) {
		super(_a, _b);
	}

	@Override
	public Vector getSolution() throws LinearEquationException {
		throw new LinearEquationException(
				"not implements in empty decompositor");
	}
	
}
