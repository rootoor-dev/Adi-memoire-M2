package la4j.linear;

import la4j.err.InverseMatrixProblemException;
import la4j.matrix.Matrix;

public interface InverseMatrixProblem {

	public Matrix getMatrix();

	public Matrix getInverseMatrix() throws InverseMatrixProblemException;

}
