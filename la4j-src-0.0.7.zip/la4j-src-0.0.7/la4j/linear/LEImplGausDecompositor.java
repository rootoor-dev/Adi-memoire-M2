package la4j.linear;

import la4j.err.LinearEquationException;
import la4j.matrix.Matrix;
import la4j.matrix.MatrixUtils;
import la4j.vector.Vector;

public class LEImplGausDecompositor extends AbstractLinearEquation implements
		LinearEquation {

	public LEImplGausDecompositor(Matrix _a, Vector _b) {
		super(_a, _b);
	}

	@Override
	public Vector getSolution() throws LinearEquationException {
		// ** try to build extends matrix

		Matrix extenda = MatrixUtils.expandMatrixByColumn(a, b);

		Matrix treangle = createExtendTreangleMatrix(extenda);

		Vector x = retraceGaus(treangle);

		return x;
	}

	private Matrix createExtendTreangleMatrix(Matrix m)
			throws LinearEquationException {
		Matrix treangle = m.clone();

		/* loop by col */
		for (int i = 0; i < treangle.rows(); i++) {
			int r = -1;
			double maxItem = 0.0;

			for (int k = i; k < treangle.rows(); k++) {
				if (Math.abs(treangle.get(k, i)) > maxItem) {
					maxItem = Math.abs(treangle.get(k, i));
					r = k;
				}
			}

			// is matrix confluent
			if (r == -1 || Math.abs(maxItem) < EPS) {
				if (treangle.get(i, treangle.columns()) > EPS)
					throw new LinearEquationException("matrix is confluent");
				else
					throw new LinearEquationException(
							"linear equation has many solution");
			}

			if (r > i) {
				treangle.swapRows(r, i);
			}

			for (int j = i + 1; j < treangle.rows(); j++) {
				double C = treangle.get(j, i) / treangle.get(i, i);

				for (int k = i; k < treangle.columns(); k++) {
					if (k == i) {
						treangle.set(j, k, C);
					} else {
						treangle.set(j, k, treangle.get(j, k)
								- treangle.get(i, k) * C);
					}
				}
			}
		}
		return treangle;
	}

	private Vector retraceGaus(Matrix exta) throws LinearEquationException {

		if (exta.trace() == (double) 0.0) {
			throw new LinearEquationException("linear equation has no solution");
		}

		double x[] = new double[variables()];
		for (int i = x.length - 1; i >= 0; i--) {
			double summand = 0;
			for (int j = i + 1; j < x.length; j++) {
				summand += x[j] * exta.get(i, j);
			}

			x[i] = (exta.get(i, exta.columns() - 1) - summand) / exta.get(i, i);

		}

		return new Vector(x);
	}
}
