package la4j.linear;

import la4j.matrix.Matrix;

public abstract class AbstractInverseMatrixProblem implements InverseMatrixProblem {
	protected Matrix matrix;
	
	public AbstractInverseMatrixProblem(Matrix a) {
		matrix = a;
	}

	@Override
	public Matrix getMatrix() {
		return matrix;
	}

}
