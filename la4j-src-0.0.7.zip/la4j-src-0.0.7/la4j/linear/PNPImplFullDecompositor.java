package la4j.linear;

import java.util.ArrayList;
import java.util.List;

import la4j.err.MatrixException;
import la4j.err.PropNumbersProblemException;
import la4j.matrix.Matrix;
import la4j.matrix.MatrixFactory;
import la4j.util.Pair;
import la4j.vector.Vector;
import la4j.vector.VectorFactory;

public class PNPImplFullDecompositor extends AbstractPropNumbersProblem
		implements PropNumbersProblem {

	public static final int MAX_ITERATIONS = 100000;

	public PNPImplFullDecompositor(Matrix _matrix) {
		super(_matrix);
	}

	@Override
	public Pair<Double, Vector>[] getPropNumbers()
			throws PropNumbersProblemException {

		if (!matrix.isSymmetric()) {
			throw new PropNumbersProblemException("matrix is not symmetric");
		}

		List<Pair<Double, Vector>> nums = new ArrayList<Pair<Double, Vector>>();

		try {

			int n = matrix.rows();

			Matrix a = matrix.clone();

			Vector r = generateR(a);

			Matrix d = MatrixFactory.createSquareIdentityMatrix(n);

			int iter = 0;

			do {

				int k = findMax(r, -1);
				int l = findMax(a.getRow(k), k);

				Matrix u = generateU(a, k, l);

				d = d.multiply(u);

				Matrix c = a.multiply(u);

				a = u.transpose().multiply(c);

				r.set(k, generateRi(a.getRow(k), k));
				r.set(l, generateRi(a.getRow(l), l));

				iter++;

			} while (r.norm() > EPS && iter < MAX_ITERATIONS);

			if (iter < MAX_ITERATIONS) {
				for (int i = 0; i < a.rows(); i++) {
					nums.add(new Pair<Double, Vector>(a.get(i, i), d
							.getColumn(i)));
				}
			} else {
				throw new PropNumbersProblemException("to many iterations");
			}

		} catch (MatrixException ex) {
			throw new PropNumbersProblemException(ex.getMessage());
		}

		return (Pair<Double, Vector>[]) nums.toArray(new Pair[nums.size()]);
	}

	private int findMax(Vector r, int exl) {
		int ind = exl == 0 ? 1 : 0;

		for (int i = 0; i < r.length(); i++) {
			if (i != exl && Math.abs(r.get(ind)) < Math.abs(r.get(i))) {
				ind = i;
			}
		}

		return ind;
	}

	private Vector generateR(Matrix a) {
		Vector res = VectorFactory.createVector(a.rows());
		for (int i = 0; i < a.rows(); i++) {
			res.set(i, generateRi(a.getRow(i), i));
		}
		return res;
	}

	private double generateRi(Vector v, int k) {
		double sum = 0;
		for (int i = 0; i < v.length(); i++) {
			if (i != k) {
				sum += v.get(i) * v.get(i);
			}
		}

		return sum;
	}

	private Matrix generateU(Matrix a, int k, int l) {
		double u[][] = MatrixFactory
				.createIdentityMatrix(a.rows(), a.columns()).toArray();

		double alpha;
		double beta;

		if ((a.get(k, k) - a.get(l, l)) < EPS) {
			alpha = beta = Math.sqrt(0.5);
		} else {
			double mu = 2 * a.get(k, l) / (a.get(k, k) - a.get(l, l));
			mu = 1 / Math.sqrt(1 + mu * mu);
			alpha = Math.sqrt(0.5 * (1 + mu));
			beta = Math.signum(mu) * Math.sqrt(0.5 * (1 - mu));
		}

		u[k][k] = alpha;
		u[l][l] = alpha;
		u[k][l] = -beta;
		u[l][k] = beta;

		return MatrixFactory.createMatrix(u);
	}

}
